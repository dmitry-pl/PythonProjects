from game import Game

if __name__ == "__main__":
    # Создаем игру и запускаем её
    game = Game()
    game.run()